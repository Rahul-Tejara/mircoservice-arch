var mysql      = require('mysql');
var connection = require('./db');

exports.handler = function(event, context) {
//   var username = event['body-json'].username;
//   var password = event['body-json'].password;
//   var email = event['body-json'].email;
 
  connection.query('delete from user', function (err, row) {
    if (err){
        context.succeed({ 'success': false, 'message': err });
    }
     if (row != undefined) {
         context.succeed({ 'success': true, 'message': 'Deleted login user record Successfully!' });
    
    } else {
        context.succeed({ 'success': false, 'message': 'Somthing is wrong! please try again' });
     
    }
    
  });

};