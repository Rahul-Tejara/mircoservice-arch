var mysql      = require('mysql');
var connection = require('./db');
exports.handler = function(event, context) {

 
  connection.query('select * from user', function (err, row) {
    if (err){
        context.succeed({ 'success': false, 'message': err });
    }
     if (row != undefined) {
         console.log(row);
         context.succeed({ 'success': true, 'message': 'successFUlly fetched.', 'data': row });
    
    } else {
        context.succeed({ 'success': false, 'message': 'Somthing is wrong! please try again' });
     
    }
    
  });
};