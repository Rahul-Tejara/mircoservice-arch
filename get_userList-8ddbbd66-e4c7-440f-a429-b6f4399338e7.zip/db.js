var mysql = require('mysql');
var connection = mysql.createConnection({
    host     : 'mydb.cfw8zbmewztl.us-east-1.rds.amazonaws.com',
    user     : 'tejra123',
    password : 'rahul12345',
    database : 'mydb',
    port: '3306',
});

connection.connect(function(err) {
    if (err)
    { 
        throw err
    }
    else {
        console.log("connected");
    }

});

module.exports = connection;