var mysql      = require('mysql');
var connection = require('./db');

exports.handler = function(event, context) {
  var username = event['body-json'].username;
  var password = event['body-json'].password;
  var email = event['body-json'].email;
 
  connection.query('INSERT INTO user(username,password,email) VALUES(?, ?, ?)',[username, password, email], function (err, row) {
    if (err){
        context.succeed({ 'success': false, 'message': err });
    }
     if (row != undefined) {
         context.succeed({ 'success': true, 'message': 'User Register Successfully!' });
    
    } else {
        context.succeed({ 'success': false, 'message': 'Somthing is wrong! please try again' });
     
    }
    
  });

};