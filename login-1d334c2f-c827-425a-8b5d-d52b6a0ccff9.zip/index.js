var mysql      = require('mysql');
var connection = require('./db');
exports.handler = function(event, context) {
    console.log(event['body-json']);
  var username = event['body-json'].username;
  var password = event['body-json'].password;
  console.log(password);

 connection.query('select * from user where username = ? and password = ?', [username, password], function (err, row) {
    if (err){
        context.succeed({ 'success': false, 'message': err });
    }
    
    if (row.length > 0) {
         context.succeed({ 'success': true, 'message': row[0].username });
    
    } else {
        context.succeed({ 'success': false, 'message': 'user not found please try again' });
     
    }
  });

};